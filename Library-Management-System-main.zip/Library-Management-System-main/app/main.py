from fastapi import FastAPI
from .core import init_db
from .routers import books, members, loans

app = FastAPI(title="Library Management System")

init_db()

app.include_router(books.router)
app.include_router(members.router)
app.include_router(loans.router)

