# models.py
from datetime import date, datetime
from typing import Optional
from sqlmodel import SQLModel, Field, Relationship

class Book(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    title: str
    author: str
    isbn: str = Field(unique=True, index=True)
    copies_total: int = 1
    copies_available: int = 1
    loans: list["Loan"] = Relationship(back_populates="book")

class Member(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    email: str = Field(index=True, unique=True)
    active: bool = True
    loans: list["Loan"] = Relationship(back_populates="member")

class Loan(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    book_id: int = Field(foreign_key="book.id")
    member_id: int = Field(foreign_key="member.id")
    issue_date: datetime = Field(default_factory=datetime.utcnow)
    due_date: date
    returned: bool = False

    book: Book = Relationship(back_populates="loans")
    member: Member = Relationship(back_populates="loans")
