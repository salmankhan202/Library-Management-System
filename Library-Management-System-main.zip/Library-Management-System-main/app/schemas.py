from datetime import date, datetime
from typing import Optional
from pydantic import BaseModel, EmailStr

###########
# Books
###########
class BookBase(BaseModel):
    title: str
    author: str
    isbn: str

class BookCreate(BookBase):
    copies_total: int = 1

class BookRead(BookBase):
    id: int
    copies_total: int
    copies_available: int

    class Config:
        orm_mode = True        # tells Pydantic to read data from SQLModel

###########
# Members
###########
class MemberBase(BaseModel):
    name: str
    email: EmailStr

class MemberCreate(MemberBase):  # nothing extra for now
    pass

class MemberRead(MemberBase):
    id: int
    active: bool

    class Config:
        orm_mode = True

###########
# Loans
###########
class LoanBase(BaseModel):
    book_id: int
    member_id: int
    due_date: date

class LoanCreate(LoanBase):      # nothing extra
    pass

class LoanRead(LoanBase):
    id: int
    issue_date: datetime
    returned: bool

    class Config:
        orm_mode = True
