from sqlmodel import Session, select
from .models import Book, Member, Loan

# ---------- Books ----------
def create_book(session: Session, book_in: Book) -> Book:
    session.add(book_in)
    session.commit()
    session.refresh(book_in)
    return book_in

def get_book(session: Session, book_id: int) -> Book | None:
    return session.get(Book, book_id)

def list_books(session: Session) -> list[Book]:
    return session.exec(select(Book)).all()

# ---------- Members ----------
def create_member(session: Session, member_in: Member) -> Member:
    session.add(member_in)
    session.commit()
    session.refresh(member_in)
    return member_in

def list_members(session: Session) -> list[Member]:
    return session.exec(select(Member)).all()

# ---------- Loans ----------
def issue_loan(session: Session, loan_in: Loan) -> Loan:
    book = session.get(Book, loan_in.book_id)
    if not book:
        raise ValueError("Book not found")
    if book.copies_available < 1:
        raise ValueError("Book not available")

    book.copies_available -= 1
    session.add(loan_in)
    session.commit()
    session.refresh(loan_in)
    return loan_in

def return_loan(session: Session, loan_id: int) -> Loan:
    loan = session.get(Loan, loan_id)
    if not loan or loan.returned:
        raise ValueError("Invalid loan")

    loan.returned = True
    loan.book.copies_available += 1
    session.commit()
    session.refresh(loan)
    return loan

def list_loans(session: Session) -> list[Loan]:
    return session.exec(select(Loan)).all()

