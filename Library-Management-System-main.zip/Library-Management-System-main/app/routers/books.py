from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import Session
from ..core import get_session
from ..models import Book
from ..schemas import BookCreate, BookRead
from ..crud import create_book, get_book, list_books

router = APIRouter(prefix="/books", tags=["books"])

@router.post("/", response_model=BookRead, status_code=status.HTTP_201_CREATED)
def add_book(payload: BookCreate, session: Session = Depends(get_session)):
    book = Book(**payload.dict(), copies_available=payload.copies_total)
    return create_book(session, book)

@router.get("/", response_model=list[BookRead])
def get_books(session: Session = Depends(get_session)):
    return list_books(session)

@router.get("/{book_id}", response_model=BookRead)
def get_single(book_id: int, session: Session = Depends(get_session)):
    book = get_book(session, book_id)
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    return book

