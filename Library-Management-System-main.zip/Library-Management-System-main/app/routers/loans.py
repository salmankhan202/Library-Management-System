from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import Session
from ..core import get_session
from ..models import Loan
from ..schemas import LoanCreate, LoanRead
from ..crud import issue_loan, return_loan, list_loans

router = APIRouter(prefix="/loans", tags=["loans"])

@router.post("/", response_model=LoanRead, status_code=status.HTTP_201_CREATED)
def create_loan(payload: LoanCreate, session: Session = Depends(get_session)):
    loan = Loan(**payload.dict())
    try:
        return issue_loan(session, loan)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@router.post("/{loan_id}/return", response_model=LoanRead)
def close_loan(loan_id: int, session: Session = Depends(get_session)):
    try:
        return return_loan(session, loan_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@router.get("/", response_model=list[LoanRead])
def get_loans(session: Session = Depends(get_session)):
    return list_loans(session)

