from fastapi import APIRouter, Depends, status
from sqlmodel import Session
from ..core import get_session
from ..models import Member
from ..schemas import MemberCreate, MemberRead
from ..crud import create_member, list_members

router = APIRouter(prefix="/members", tags=["members"])

@router.post("/", response_model=MemberRead, status_code=status.HTTP_201_CREATED)
def add_member(payload: MemberCreate, session: Session = Depends(get_session)):
    member = Member(**payload.dict())
    return create_member(session, member)

@router.get("/", response_model=list[MemberRead])
def get_members(session: Session = Depends(get_session)):
    return list_members(session)

